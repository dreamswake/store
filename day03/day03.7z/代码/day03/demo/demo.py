'''
   3.循环结构：
        条件型：while
        次数型循环：for
            for 变量  in  range(0,10)
            # range() 范围
    4.
    *
    *
    *
    *
    *




    *   #   0 1         i = 0
    **  #   0 2         i = 1
    ***    #  0  3      i = 2
    ****  # 0   4       i = 3
    *****   # 0    5    i = 4
'''

num = input("请输入乘法表的层数：")
num = int(num)
for i in range(1,num + 1):
    for j in range(1,i+1):
        print(j,"x",i,"=",(j*i),"\t",end="")
    print()


# for i in range(0,5):
#     for j in range(0,i+1):
#         print("*",end="")  # end=""不换行
#     print()












# i = 0
# while i <= 10:
#     print(i)
#     i = i + 1

# for i in range(0,11,2):
#     print(i)











