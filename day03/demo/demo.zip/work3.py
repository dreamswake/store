i=1
num=1
for i in range(1,21):
    num1=i
    num=num*num1
    print(num)



