list = [1,4,7,5,8,2,1,3,4,5,9,7,6,1,10]


for i in range(0,len(list)):
    k=1
    for j in range(i+1,len(list)):
        if list[i]==list[j]:
            k=k+1
    print(k)









