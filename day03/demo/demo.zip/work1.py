for i in range(0,7):
    for j in range(0,6-i):
        print(" ",end="")
    for k in range(0,i+1):
        print("*",end=" ")
    print()




# for f in range(0,7):
#     for l in range(0,6-f):
#         print(" ",end="")
#     for g in range(0,f+1):
#         print("*",end=" ")
#     print("")









