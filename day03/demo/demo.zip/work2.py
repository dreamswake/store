i=0
high=0
while high<20:
    high=high+3
    i=i+1
    if high>=20:
        print("第",i,"天")
    else:
        high=high-2












