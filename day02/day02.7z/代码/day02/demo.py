# author:jason
'''
    1.注释：不参与程序执行和运算
        1.1 # 表示单行注释
    2.变量：可以变化存储的量：变量
        x = 6
        student = 56
        2.1 规则： 26个英文字母大小写  + 10个数字 + _  =  63个字符
        2.2 规范：
            数字不能开头，
            禁止使用中文命名（各大企业）,
            尽量用英文单词去命名
            禁止使用python已经规定的关键字:if  else  for（help("keywords")）
        +  -  *  /(保留小数位)   //（只取整数商）
'''
username = "贾生"
age = 67
sex = '男'
high = 1.80
weight = 70

print("我叫",username,"，我今年",age,"岁!我是",sex,"性,我的身高",high,",我的体重",weight)






