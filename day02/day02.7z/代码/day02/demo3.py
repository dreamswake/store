name1 = "苹果"
price1 = 2.5
quanlity1 = "A+"
num1 = 500

name2 = ""

print(name1,"\t\t",price1,"\t\t",quanlity1,"\t\t",num1)
print("总金额：",(price1 * num1),"￥")