age=int(input("请输入年龄:"))
if age>=18:
    print("可以进入电影院")
else:
    print("年龄不合法")