i=1
num=0
while i<=10:
    a=int(input("请输入一个数:"))
    num=num+a
    i=i+1
print("十个数的和为:",num)