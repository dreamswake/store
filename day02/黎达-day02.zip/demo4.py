stu1=45
stu2=30
print(stu1+stu2)