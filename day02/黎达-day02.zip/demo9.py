import random
num=int(random.random()*100)
print(num)
if num>50 and num<150:
    print("符合要求")
else:
    print("不符合要求")




